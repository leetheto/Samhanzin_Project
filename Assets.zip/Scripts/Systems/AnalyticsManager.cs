using UnityEngine;

public class AnalyticsManager : MonoBehaviour
{
    public static AnalyticsManager Instance;

    private void Awake()
    {
        if (Instance != null) Destroy(gameObject);
        Instance = this;
    }

    public void LogEvent(string eventName, string value)
    {
        Debug.Log($"[���] {eventName}: {value}");
    }

    public void TrackCurrency(string type, int amount)
    {
        Debug.Log($"[���] �ڿ����� - {type}: {amount}");
    }
}
